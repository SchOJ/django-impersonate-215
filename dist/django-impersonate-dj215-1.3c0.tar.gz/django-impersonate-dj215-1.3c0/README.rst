# django-impersonate-dj215

Patched version of [django-impoersonate](https://pypi.org/project/django-impersonate/).

Will be put down after [the pull request](https://bitbucket.org/petersanchez/django-impersonate/pull-requests/34) get merged.